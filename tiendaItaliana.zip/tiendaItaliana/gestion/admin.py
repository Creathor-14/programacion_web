from django.contrib import admin
#from .models import Formulario
# Register your models here.

#admin.site.register(Formulario)